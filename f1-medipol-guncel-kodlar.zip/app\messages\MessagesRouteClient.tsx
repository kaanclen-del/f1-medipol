"use client";

import { useEffect, useState } from "react";
import MessagesClient from "@/components/MessagesClient";

function isMobileOrTablet() {
  return window.innerWidth <= 1199 ||
    (window.matchMedia("(pointer: coarse)").matches && window.innerWidth <= 1500);
}

export default function MessagesRouteClient() {
  const [ready, setReady] = useState(false);
  useEffect(() => {
    if (isMobileOrTablet()) { setReady(true); return; }
    const stored = window.sessionStorage.getItem("f1-dm-last-page") || "/";
    const safe = stored.startsWith("/") && !stored.startsWith("//") &&
      !stored.startsWith("/messages") ? stored : "/";
    const dest = new URL(safe, window.location.origin);
    const current = new URLSearchParams(window.location.search);
    dest.searchParams.set("f1dm", "open");
    if (current.get("dm")) dest.searchParams.set("dm", current.get("dm")!);
    if (current.get("view") === "groups") dest.searchParams.set("dmview", "groups");
    window.location.replace(dest.pathname + dest.search + dest.hash);
  }, []);
  return ready ? <MessagesClient mode="page" /> : null;
}
