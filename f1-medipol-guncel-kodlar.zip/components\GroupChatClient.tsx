"use client";

import { useCallback, useEffect, useRef, useState, type FormEvent } from "react";
import { createClient } from "@/utils/supabase/client";
import css from "./GroupChatClient.module.css";

type Group = { group_id: string; title: string; owner_id: string; member_count: number; last_message: string | null; last_at: string | null; unread_count: number };
type ChatMessage = { id: string; sender_id: string; author_name: string; body: string; created_at: string };
type Friend = { user_id: string; display_name: string; avatar_url: string | null };

const time = (date: string) => new Date(date).toLocaleString("tr-TR", {day:"numeric",month:"short",hour:"2-digit",minute:"2-digit"});

export default function GroupChatClient({ userId, onBack }: {userId: string; onBack: () => void}) {
  const [db] = useState(() => createClient());
  const [groups,setGroups] = useState<Group[]>([]);
  const [active,setActive] = useState<string | null>(null);
  const [messages,setMessages] = useState<ChatMessage[]>([]);
  const [friends,setFriends] = useState<Friend[]>([]);
  const [creating,setCreating] = useState(false);
  const [title,setTitle] = useState("");
  const [chosen,setChosen] = useState<string[]>([]);
  const [draft,setDraft] = useState("");
  const [busy,setBusy] = useState(false);
  const [error,setError] = useState("");
  const latest = useRef<string | null>(null);
  const bottom = useRef<HTMLDivElement>(null);
  const current = groups.find(group => group.group_id === active);
  useEffect(()=>{latest.current=active;},[active]);

  const refresh = useCallback(async () => {
    const {data,error:readError} = await db.rpc("dm_group_list");
    if (readError) {setError("Grup sohbeti için DM_GROUPS_V7.sql kurulumu gerekli: " + readError.message);return;}
    setGroups((data||[]) as Group[]);
    window.dispatchEvent(new Event("f1-dm-groups-updated"));
  },[db]);

  const loadMessages = useCallback(async (groupId:string) => {
    const {data,error:readError} = await db.rpc("dm_group_get_messages",{p_group:groupId,p_limit:80});
    if (readError) {setError(readError.message);return;}
    if (latest.current !== groupId) return;
    setMessages((data||[]) as ChatMessage[]);
    const {error:readError2}=await db.rpc("dm_group_mark_read",{p_group:groupId});
    if(!readError2) void refresh();
  },[db,refresh]);

  useEffect(()=>{
    void refresh();
    const onFocus=()=>{void refresh();if(latest.current)void loadMessages(latest.current);};
    const interval=window.setInterval(()=>{if(!document.hidden)onFocus();},6000);
    window.addEventListener("focus",onFocus);
    return ()=>{window.clearInterval(interval);window.removeEventListener("focus",onFocus);};
  },[refresh,loadMessages]);
  useEffect(()=>{if(active)void loadMessages(active);},[active,loadMessages]);
  useEffect(()=>{bottom.current?.scrollIntoView({block:"end"});},[messages.length,active]);

  const startCreate = async () => {
    setCreating(true);setError("");setChosen([]);setTitle("");
    const {data,error:readError} = await db.rpc("dm_list_friends");
    if(readError){setError(readError.message);return;}
    setFriends((data||[]) as Friend[]);
  };
  async function createGroup(event:FormEvent<HTMLFormElement>) {
    event.preventDefault();if(busy)return;
    if(chosen.length<2){setError("Grup oluşturmak için en az iki arkadaşını seç.");return;}
    setBusy(true);setError("");
    try {
      const {data,error:writeError}=await db.rpc("dm_group_create",{p_title:title.trim(),p_members:chosen});
      if(writeError)throw writeError;
      setCreating(false);setActive(data as string);latest.current=data as string;
      await refresh();
    }catch(e){setError(e instanceof Error?e.message:"Grup oluşturulamadı.");}
    finally{setBusy(false);}
  }
  async function send(event:FormEvent<HTMLFormElement>) {
    event.preventDefault();if(!active||!draft.trim()||busy)return;
    const body=draft.trim();setBusy(true);setError("");
    const {error:sendError}=await db.rpc("dm_group_send",{p_group:active,p_body:body});
    if(sendError)setError(sendError.message);
    else{setDraft("");await loadMessages(active);void refresh();}
    setBusy(false);
  }
  async function leaveGroup() {
    if(!active||busy||!window.confirm(`“${current?.title||"Grup"}” sohbetinden ayrılmak istiyor musun?`))return;
    setBusy(true);setError("");
    const {error:leaveError}=await db.rpc("dm_group_leave",{p_group:active});
    if(leaveError)setError(leaveError.message);
    else {setActive(null);latest.current=null;setMessages([]);await refresh();}
    setBusy(false);
  }

  return <div className={css.root}>
    {creating ? <>
      <div className={css.toolbar}><button type="button" onClick={()=>{setCreating(false);setError("");}} className={css.back}>← Gruplar</button><strong>Yeni grup oluştur</strong></div>
      <form className={css.creation} onSubmit={createGroup}>
        <label className={css.label} htmlFor="f1-group-name">Grup adı</label>
        <input id="f1-group-name" value={title} onChange={e=>setTitle(e.target.value)} minLength={3} maxLength={48} required placeholder="Örneğin: F1 Medipol Yarış Tayfası"/>
        <div className={css.label}>Arkadaşlarını seç <small>En az 2 kişi · {chosen.length} seçildi</small></div>
        <div className={css.members}>
          {friends.length<2 && <p className={css.empty}>Grup için en az iki onaylanmış arkadaşın olmalı.</p>}
          {friends.map(friend=><label key={friend.user_id} className={css.member}>
            <input type="checkbox" checked={chosen.includes(friend.user_id)} onChange={e=>setChosen(old=>e.target.checked?[...old,friend.user_id]:old.filter(id=>id!==friend.user_id))} disabled={!chosen.includes(friend.user_id)&&chosen.length>=19}/>
            <span className={css.avatar}>{friend.avatar_url?<img src={friend.avatar_url} alt=""/>:friend.display_name[0]}</span>
            <span>{friend.display_name}</span>
          </label>)}
        </div>
        <button className={css.primary} type="submit" disabled={busy||chosen.length<2||title.trim().length<3}>{busy?"Oluşturuluyor...":"Grubu oluştur"}</button>
      </form>
    </> : active && current ? <>
      <div className={css.toolbar}>
        <button type="button" onClick={()=>{setActive(null);setMessages([]);}} className={css.back}>← Gruplar</button>
        <div className={css.groupIdentity}><strong>{current.title}</strong><small>{current.member_count} üye · Grup sohbeti</small></div>
        <button type="button" onClick={()=>void leaveGroup()} disabled={busy} className={css.leave}>Ayrıl</button>
      </div>
      <div className={css.messages}>
        {messages.length===0&&<div className={css.empty}>İlk grup mesajını gönder! 🏁</div>}
        {messages.map(msg=><div key={msg.id} className={`${css.msgRow} ${msg.sender_id===userId?css.mine:""}`}>
          <div className={css.bubble}>
            {msg.sender_id!==userId&&<strong className={css.author}>{msg.author_name}</strong>}
            <p>{msg.body}</p><small>{time(msg.created_at)}</small>
          </div>
        </div>)}
        <div ref={bottom}/>
      </div>
      <form className={css.composer} onSubmit={send}>
        <input aria-label="Gruba mesaj yaz" placeholder="Gruba mesaj yaz..." maxLength={1500} value={draft} onChange={e=>setDraft(e.target.value)}/>
        <button type="submit" disabled={busy||!draft.trim()} aria-label="Gönder">➤</button>
      </form>
    </> : <>
      <div className={css.toolbar}>
        <button type="button" onClick={onBack} className={css.back}>← Sohbetler</button>
        <strong>Grup sohbetleri</strong>
        <button type="button" className={css.new} onClick={()=>void startCreate()}>＋ Yeni grup</button>
      </div>
      <div className={css.groupList}>
        {groups.length===0&&<div className={css.empty}>Henüz grup sohbetin yok. En az iki arkadaşını seçip ilk grubunu oluşturabilirsin.</div>}
        {groups.map(group=><button key={group.group_id} className={css.groupItem} type="button" onClick={()=>{setActive(group.group_id);latest.current=group.group_id;setError("");}}>
          <span className={css.groupIcon}>♜</span><span className={css.groupCopy}><strong>{group.title}</strong><small>{group.last_message||`${group.member_count} kişilik grup`}</small></span>
          {Number(group.unread_count)>0&&<b className={css.badge}>{group.unread_count}</b>}
        </button>)}
      </div>
    </>}
    {error&&<div className={css.error} role="status">{error}</div>}
  </div>;
}
