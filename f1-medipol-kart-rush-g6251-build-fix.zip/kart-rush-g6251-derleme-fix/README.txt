Kart Rush G6.2.5.1 -- G6.2.5 TypeScript build onarimi
G6.2.5 kurulu olmali.
setAudioEnabled(true) eski kalintisi kaldirildi; halihazirda ses aktivasyonu korunur.
Proje dosyasi SHA256 ile dogrulanir, farkli surumde degistirmez.
Windows CRLF uyumlu, otomatik yedek ve RESTORE.cjs icerir.
Bu paket Header veya baslangic popup kodunu degistirmez.
