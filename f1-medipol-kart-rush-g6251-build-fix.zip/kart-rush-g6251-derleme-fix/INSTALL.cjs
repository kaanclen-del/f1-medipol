#!/usr/bin/env node
'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const cwd=process.cwd();
const abort=(m)=>{console.error('[HATA] '+m);process.exit(1);};
const manifest=JSON.parse(fs.readFileSync(path.join(__dirname,'manifest.json'),'utf8'));
if(!fs.existsSync(path.join(cwd,'package.json')))abort('Proje klasorunde calistir.');
const getHash=s=>crypto.createHash('sha256').update(s.replace(/\r\n/g,'\n')).digest('hex');
const entries=manifest.files.map(m=>{
 const dest=path.resolve(cwd,m.target),source=path.resolve(__dirname,m.payload);
 if(!dest.startsWith(cwd+path.sep)||!fs.existsSync(dest)||!fs.existsSync(source))abort('Dosya bulunamadi: '+m.target);
 const current=fs.readFileSync(dest,'utf8'),next=fs.readFileSync(source,'utf8');
 if(getHash(next)!==m.newSha)abort('Paket dogrulama hatasi.');
 return {m,dest,current,next,currentSha:getHash(current)};
});
if(entries.every(e=>e.currentSha===e.m.newSha)){console.log('[OK] G6.2.5.1 zaten kurulu.');process.exit(0);}
for(const e of entries)if(e.currentSha!==e.m.oldSha)abort('Mevcut kod G6.2.5 ile eslesmiyor, uzerine yazilmadi: '+e.m.target+'\nSHA '+e.currentSha);
const backups=path.join(cwd,'.kart-rush-backups');fs.mkdirSync(backups,{recursive:true});
const bdir=fs.mkdtempSync(path.join(backups,'g6251-buildfix-'+new Date().toISOString().replace(/[:.]/g,'-')+'-'));
try{
 for(const e of entries){const bfile=path.join(bdir,e.m.target);fs.mkdirSync(path.dirname(bfile),{recursive:true});fs.copyFileSync(e.dest,bfile);if(getHash(fs.readFileSync(bfile,'utf8'))!==e.m.oldSha)throw Error('Yedekleme dogrulama hatasi');}
 fs.writeFileSync(path.join(bdir,'index.json'),JSON.stringify(manifest));
}catch(err){abort('Yedek olusturulamadi: '+err.message);}
try{
 for(const e of entries){const ending=e.current.includes('\r\n')?'\r\n':'\n';const tmp=e.dest+'.g6251-tmp';
  fs.writeFileSync(tmp,e.next.replace(/\n/g,ending));if(getHash(fs.readFileSync(tmp,'utf8'))!==e.m.newSha)throw Error('Yazma dogrulama hatasi');fs.renameSync(tmp,e.dest);}
}catch(err){for(const e of entries)try{fs.copyFileSync(path.join(bdir,e.m.target),e.dest)}catch{};abort('Kurulum geri alindi: '+err.message);}
console.log('[OK] G6.2.5.1 TypeScript ses kontrolu hatasi onarildi.');
console.log('Yedek: '+bdir);console.log('SONRAKI: npm.cmd run build -- --webpack');
