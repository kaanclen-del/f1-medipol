#!/usr/bin/env node
'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const cwd=process.cwd(),dir=path.join(cwd,'.kart-rush-backups');
const fail=m=>{console.error('[HATA] '+m);process.exit(1);};
if(!fs.existsSync(dir))fail('Yedek bulunamadi.');
const names=fs.readdirSync(dir).filter(n=>n.startsWith('g6251-buildfix-')).sort().reverse();
if(!names.length)fail('G6.2.5.1 yedegi bulunamadi.');
const bd=path.join(dir,names[0]);const meta=JSON.parse(fs.readFileSync(path.join(bd,'index.json'),'utf8'));
const sha=s=>crypto.createHash('sha256').update(s.replace(/\r\n/g,'\n')).digest('hex');
const files=meta.files.map(f=>({...f,original:path.join(bd,f.target),dest:path.resolve(cwd,f.target)}));
for(const f of files){if(!f.dest.startsWith(cwd+path.sep)||!fs.existsSync(f.original)||!fs.existsSync(f.dest))fail('Dosya bulunamadi: '+f.target);
 if(sha(fs.readFileSync(f.dest,'utf8'))!==f.newSha)fail('G6.2.5.1 sonrasi dosya degismis, uzerine yazilmadi: '+f.target);
 if(sha(fs.readFileSync(f.original,'utf8'))!==f.oldSha)fail('Yedek dogrulamasi basarisiz: '+f.target);
}
for(const f of files)fs.copyFileSync(f.original,f.dest);
console.log('[OK] G6.2.5 surumu geri yuklendi.');
